---
title:
author:
---

Here's the latest roundup apps, upcoming meetups, tools, videos, etc from the community.

---

This site is updated with new [apps](http://electron.atom.io/apps) and [meetups](http://electron.atom.io/community) through [pull requests](https://github.com/electron/electron.atom.io/pulls) from the community. You can [watch the repository](https://github.com/electron/electron.atom.io) to get notifications of new additions or if you're not interested in _all_ of the site's changes, subscribe to the [blog RSS feed](http://electron.atom.io/feed.xml).

If you've made an Electron app or host a meetup, make a [pull request](https://github.com/electron/electron.atom.io) to add it to the site and it will make the next roundup.

### New Apps

{: .table .table-ruled .table-full-width .table-with-spacious-first-column .mb-7}
|     |     |    |
| --- | --- | -- |
| <img src="/images/apps/" width="50"> | []() | Description |


### New Meetups

{: .table .table-ruled .table-full-width .table-with-spacious-first-column .mb-7}
|     |    |
| --- | -- |
| []() | Description |
